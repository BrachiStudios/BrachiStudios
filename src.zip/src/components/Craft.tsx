import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import Reveal from "./Reveal";

const stats = [
  { value: "3–5×", label: "Faster than typical agency timelines" },
  { value: "70%", label: "Cheaper than the average SMB website" },
  { value: "Free", label: "Domain + hosting included, forever" },
];

export default function Craft() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["-8%", "8%"]);

  return (
    <section id="craft" className="relative bg-olive-950 py-24 sm:py-36">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 sm:px-8 lg:grid-cols-2 lg:gap-20">
        {/* Image */}
        <div ref={ref} className="relative order-2 lg:order-1">
          <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem] border border-olive-800">
            <motion.img
              style={{ y }}
              src="https://images.pexels.com/photos/5749190/pexels-photo-5749190.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"
              alt="A designer working late in a dimly lit studio"
              width={800}
              height={1000}
              loading="lazy"
              className="h-[116%] w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-olive-950/50 to-transparent" />
          </div>
          <Reveal
            delay={0.2}
            className="absolute -right-4 bottom-8 rounded-2xl border border-olive-700/60 bg-olive-900/90 px-6 py-5 backdrop-blur-md sm:-right-8"
          >
            <p className="font-display text-3xl font-light text-crust">∞</p>
            <p className="mt-1 text-xs uppercase tracking-[0.2em] text-cream/60">
              Detail, obsessed over
            </p>
          </Reveal>
        </div>

        {/* Text */}
        <div className="order-1 lg:order-2">
          <Reveal>
            <p className="mb-5 flex items-center gap-3 text-xs font-medium uppercase tracking-[0.3em] text-crust">
              <span className="h-px w-10 bg-crust" /> The Studio
            </p>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="font-display text-4xl font-light leading-[1.05] tracking-tight text-cream sm:text-5xl lg:text-6xl">
              We sweat the
              <br />
              <span className="italic text-crust">details</span> others skip.
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-7 max-w-lg text-lg leading-relaxed text-cream/70">
              We're a small, senior team — no account managers, no hand-offs. Every
              project is designed and built by the people you actually talk to. We
              care about typography, timing and the feel of a single hover state as
              much as the big picture. The result: sites that load fast, convert,
              and feel unmistakably yours.
            </p>
          </Reveal>

          <div className="mt-12 grid grid-cols-3 gap-6 border-t border-olive-800 pt-8">
            {stats.map((s, i) => (
              <Reveal key={s.label} delay={0.15 + i * 0.08}>
                <p className="font-display text-3xl font-light text-cream sm:text-4xl">{s.value}</p>
                <p className="mt-1 text-xs uppercase tracking-wider text-cream/55">{s.label}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
